Repository ini dibuat untuk memenuhi tugas besar 
Kapita Selekta Informatika yang diampu oleh 
dosen Ir.Mugi Praseptiawan,S.T.,M.Kom. 

Kelompok : 
Made Redy Wijaya 121140157 
Wuri Wilatiningsih 121140167 
Andrean Syahrezi 121140169 
M. Bintang Erlangga H. 121140171 
Carlos Piero Parhusip 121140193